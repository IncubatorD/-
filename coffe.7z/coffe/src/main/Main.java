package main;

import manage.Manage;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Manage modol = new Manage();
        modol.set_goods(0, "冲绳黑糖拿铁", 28, 20);
        modol.set_goods(1, "陨石拿铁", 28, 20);
        modol.set_goods(2, "标准美式", 22, 20);
        modol.set_goods(3, "橘金气泡美式", 25, 20);
        modol.set_goods(4, "黑金气泡美式", 25, 20);
        modol.set_goods(5, "卡布奇诺", 25, 20);
        modol.set_goods(6, "焦糖玛奇朵", 28, 20);
        modol.set_goods(7, "摩卡", 28, 20);
        while (true) {
            System.out.println("***欢迎使用咖啡售货机***");
            for (int i = 0; i < 8; i++) {
                if (modol.list[i].get_residue() != 0) {
                    System.out.print(i);
                    System.out.print(" ");
                    System.out.print(modol.list[i].get_name());
                    System.out.println();
                    System.out.print("  ¥" + modol.list[i].get_price());
                    System.out.print(" 剩" + modol.list[i].get_residue() + "件");
                    System.out.println();
                }
            }
            System.out.println("请选择商品(编号0~7)");
            Scanner sc = new Scanner(System.in);
            int word = sc.nextInt();
            if (word == 711) {
                System.out.println("当前收入¥" + modol.get_money());
            } else {
                while (modol.list[word].get_residue() == 0) {
                    System.out.println("请输入正确的商品编号");
                    word = sc.nextInt();
                }
                System.out.println("需要支付¥" + modol.choice(word) + ",请投币");
                double m = sc.nextDouble();
                while (m < modol.shouldpay()) {
                    System.out.println("付款失败,请正确投币,取消:0");
                    m = sc.nextInt();
                    if (m == 0) {
                        break;
                    }
                }
                if (m == 0) {
                    continue;
                }
                System.out.println("请取货:->" + modol.list[modol.buffer].get_name() + "<-,并找零¥" + modol.payment(m));
                modol.calc();
                System.out.println("******欢迎下次再来******");
                System.out.println();
            }
        }


    }
}

