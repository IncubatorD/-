package manage;

import goods.Goods;

public class Manage {
    public Goods[] list = new Goods[8];
    private double cost;
    private double pay;
    private double change;
    private double money = 0;
    public int buffer;

    public Manage() {
        for (int i = 0; i < 8; i++) {
            list[i] = new Goods();
        }
    }

    //选择商品
    public double choice(int number) {
        if (number >= 0 && number < 9) {
            this.cost = list[number].get_price();
            this.buffer = number;
        }
        return this.cost;
    }

    //需要支付
    public double shouldpay() {
        return this.cost;
    }

    //用户支付
    public double payment(double number) {
        if (number > this.cost) {
            this.pay = number;
            this.change = this.pay - this.cost;
        }
        return this.change;
    }

    //核算,取货,收钱
    public void calc() {
        this.money = this.money + this.cost;
        int value = list[buffer].get_residue();
        list[buffer].set_residue(value - 1);
        this.cost = 0;
        this.pay = 0;
        this.change = 0;
        this.buffer = 0;
    }

    //显示贩卖机余额
    public double get_money() {
        return this.money;
    }

    //设置商品
    public void set_goods(int number, String name, double price, int quantity) {
        if (number >= 0 && number < 9) {
            this.list[number].set_name(name);
            this.list[number].set_price(price);
            this.list[number].set_residue(quantity);
        }
    }

}
