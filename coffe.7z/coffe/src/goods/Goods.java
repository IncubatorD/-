package goods;

public class Goods {
    private String name;
    private double price;
    private int residue;


    public Goods() {
    }

    public Goods(String name, double price, int residue) {
        this.name = name;
        this.price = price;
        this.residue = residue;
    }

    public String get_name() {
        return this.name;
    }


    public double get_price() {
        return this.price;
    }

    public int get_residue() {
        return this.residue;
    }

    public void set_name(String name) {
        this.name = name;
    }


    public void set_price(double value) {
        this.price = value;
    }

    public void set_residue(int value) {
        this.residue = value;
    }
}
